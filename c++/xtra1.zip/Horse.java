/**
 * Name: Than, Michael
 * Project: Extra credit #1
 * Due: 3/12/18
 * Course: cs14103-w18
 *
 * Description: Horse class extends Animal class and implements Action interface
 * 
 */ 
public class Horse extends Animal implements Action {
	
	public Horse (String name) {
		super(name);
		
		}
	
	public Horse (Horse h) {
		super(h.getName());
	}
	
	@Override
	public String Speak() {
		return "neigh";
	}
@Override 
	public String toString () {
	return "This horse is named: " + getName(); 
}
	
	
	
}