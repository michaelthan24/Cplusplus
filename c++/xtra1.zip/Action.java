/**
 * Name: Than, Michael
 * Project: Extra credit #1
 * Due: 3/12/18
 * Course: cs14103-w18
 *
 * Description: Action interface implemented by Animal, Horse, and Pig classes 
 * 
 */ 
public interface Action {
	String Speak();
}
