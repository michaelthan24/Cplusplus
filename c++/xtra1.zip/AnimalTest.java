/**
 * Name: Than, Michael
 * Project: Extra credit #1
 * Due: 3/12/18
 * Course: cs14103-w18
 *
 * Description: AnimalTest class has an array of animals which is printed out what they speak
 * 
 */ 
public class AnimalTest {
	public static void main(String [] args) {
		Animal [] animals= new Animal[8];
		animals[0]= new Horse("Horse#1");
		animals[1]= new Pig("Pig#1");
		animals[2]= new Horse ("Horse#2");
		animals[3]= new Pig("Pig#2");
		animals[4]= new Horse ("Horse#3");
		animals[5]= new Pig("Pig#3");
		animals[6]= new Horse("Horse#4");
		animals[7]= new Pig("Pig#4");
		
		for (int i=0; i < animals.length;i++ ) {
			System.out.println(animals[i].Speak());
			
		}
		
	}
}
