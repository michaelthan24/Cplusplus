/**
 * Name: Than, Michael
 * Project: Extra credit #1
 * Due: 3/12/18
 * Course: cs14103-w18
 *
 * Description: Animal super class that implements the action interface
 * 
 */ 

public class Animal implements Action {
	private String name;
	public Animal (String name) {
		this.name=name;
		}
	public Animal (Animal a) {
		this(a.name);
	}
	
	public String getName () {
		return name;
	}
	
	public void setName (String name) {
		this.name=name;
	}
	
	public String toString () {
		return "Animal name is" + name;
	}

	public String Speak() {

		return "Animal sound";
	}


}
