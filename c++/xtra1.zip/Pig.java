/**
 * Name: Than, Michael
 * Project: Extra credit #1
 * Due: 3/12/18
 * Course: cs14103-w18
 *
 * Description: Pig class extends Animal class and implements Action interface
 * 
 */ 
public class Pig extends Animal implements Action{
	public Pig (String name) {
		super(name);
	}
	
	public Pig (Pig p) {
		super(p.getName());
	}
	
@Override
	public String Speak () {
		return "oink";
	}
@Override 
	public String toString () {
	return "This pig is named: " + getName();
}
	
}
